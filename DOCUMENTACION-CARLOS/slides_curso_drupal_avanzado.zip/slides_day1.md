title: Curso Drupal avanzado
author:
  name: Carlos Sánchez
  twitter: _carletex_
  url: http://carletex.com
style: styles.css
output: index_day1.html

--

# Curso Drupal 7 avanzado
## Universidad de Zaragoza

    15/16 Junio de 2016
    Carlos Sánchez

--

### Sobre mí

- Ingeniero informático UZ
- Gabinete de Imagen y Comunicación - UZ
- [Recurse Center](http://recurse.com) (FKA Hacker School)
- Desarrollador Freelance
    - PHP & Drupal & Javascript
- Enlaces
    - [github.com/carletex](https://github.com/carletex)
    - [carletex.com](http://carletex.com)
    - [@_carletex_](https://twitter.com/_carletex_)


--

# Presentaciones

--

### Sobre el curso

- "Avanzado"
- Top-down (vs. bottom-up)
- Objetivo: Modo de trabajo & Drupal way
- Práctico 99%

--

### CMS

- Gestores de contenido
- PHP: Drupal, Wordpress, Joomla, Magento, Prestashop...

____

**Problemática**
- Guardan configuración en la base de datos
    - ¿Sincronización entre entornos?
    - ¿Control de versiones?

--

### ¿Por qué Drupal?

- Open source
- Calidad código/módulos
- Comunidad
- Evolución
- **Exportar configuración**
- **Flexibilidad/Escalabilidad** (CMS - CMF)

--

![CMS learning curve](./img/cms_learning_curve.jpg)
> Fuente: [Codemonkey](http://www.codem0nk3y.com/2012/04/what-bugs-me-about-modx-and-why/cms-learning-curve/)

--

### Drupal ladder

1. User
2. Site builder
3. Themer
4. Developer
5. Software Engineer

...

X. Guru

--

### Drupal 8

- Fecha de salida ~ 6 meses.
- Componentes symfony
- Grandes mejoras
    - Edición en linea / WYSIWYG core
    - Twig
    - Bloques
    - Configuration management
    - Multi-idioma

--

### Drupal 8

Consideraciones adicionales:
- Madurez del proyecto
- Drupal 7 LTS
- Backdrop project
- Requerimientos Drupal 8
- THE DRUPAL WAY => Migración

--

### Drupal 7. Tecnologías
- Cualquier SO
- Servidor web Apache (también nginx, IIS, etc)
- Bases de datos - PDO (MySQL, PostgreSQL, SQLite, MariaDB..)
- PHP
- HTML + CSS + JS

--

### Drupal 7. Arquitectura I

- La Base de datos
- Core libraries
- Modules (core, contrib, custom)
- Hooks
- Theme system
- Otros subsistemas: Usuarios/Permisos, Entities, Bloques, Menus, Files, Fields, Form API...

--

### Drupal 7. Arquitectura II

![Drupal layers](./img/drupal_data_flow.gif)

> Fuente: [Drupal.org](https://www.drupal.org/getting-started/before/overview)

<!-- De abajo a arriba -->
--

### Drupal 7. Arquitectura III

PAC (Presentation Abstraction Control)

![PAC](./img/pac_schema.png)

> Fuente: [Wikipedia](https://en.wikipedia.org/wiki/Presentation%E2%80%93abstraction%E2%80%93control)

<!--
Parecido al MVC, diferencia en la jerarquía (A veces se le llama MVC jerárquico)
Cada agente se preocupa de las 3 cosas -->

--

### Drupal 7. Arquitectura IV

PAC (Presentation Abstraction Control)

![PAC](./img/hierarchical_mvc.png)

> Fuente: [Robknight](http://robknight.org.uk/blog/2011/02/explaining-architectural-tiers-drupal/)

<!-- Pagina > bloques (modelo = data, view = theme, controller (hook_block).
En MVC flat los bloques devolverían una estructura de datos y la vista general haría render -->

--

### Drupal 7. Hooks

- Pieza más importante de la arquitectura Drupal
- Manera de extender/alterar funcionalidad

```php
// node.module
module_invoke_all('node_delete', $node);

// mimodulo.module
function mimodulo_node_delete($node) { ... }
```

- Modulos ~100% Implementación de hooks
- Implementar propios hooks
- Alter hooks vs Intercepting hooks

--


### Drupal 7. Modo de trabajo

- Perfiles de instalación
- Features + ...
    - D8: Features O Configuration management (ahora también D7!)
- Updates: hook_update_7XXX
- Control de versiones

--

### Drupal7. Perfiles de instalación

- Contenedor
    - Modules (contrib, custom, features)
    - Themes
    - Libraries
- Paquete completo (CVS!)

--

### Drupal7. Features

- Configuración BD <=> archivos
- 3 estados principales
	- **Default** (C = UG = BD)
	- **Overridden** (C != UG = BD || C = LG != BD)
	- **Needs review** (C != UG != BD)


- Revert VS. Recreate
- ¿Qué exportar?
- Añadidos: Strongarm + Features extra + role export...

<!-- Que exportar: ejemplo bloques. IDS, no bueno -->

--

### Drupal7. Updates

Cambios en BD, no exportados en features
ej:
- Añadir términos a una taxonomía
- Colocar un bloque nuevo
- Desactivar un módulo

```php
/**
 * Insert terms on the 'product' taxonomy
 */
mimodulo_update_7002() {
	...
}
```

--

### Drupal7. Control de versiones

- Control de versiones ^^
- Repositorio contiene perfil de instalación
- Deploys automáticos
    - Ej. git hooks + drush

```sh
drush updatedb -y && drush fra -y && drush cc all
```

--

### Drupal 7. TO-(not)DO list

- Don't hack the core!
- Cambios a "pelo" (INSERT into node..)
- NO PHP Filter
- Al tema lo que es del tema
- Explosión de módulos (vs. Leonardo Da Vinci)

--

### Drupal7. Tools

- Drush
- Devel
- [simplytest.me](https://simplytest.me/)

--


# Code!

--

### Extras

- Router (Menu)
- Form API
- Custom entities
- Theming
- Migrate
- ....

--

### Entidades

- Abstracción de funcionalidad para diferentes componentes
    (Nodes, Users...)

**Entities**:
- Entity Types
- Bundles
- Properties && Fields
- Entidad

<!-- fields para todas entitades, entity->save() -->

--

### Entidades: Entity Types

En Drupal 7:

- Nodes
- Comments
- Users
- Taxonomy (terms & vocabularies)
- Files
- No blocks :( => Bean!
- Other entities
    - **Custom**: Recomendado usar Entity API
    - **Contrib**: Drupal commerce

--

### Entidades: Bundles

Cuando queremos que nuestras entidades sean «fieldables».

- Node => Página básica, Artículo, ...
- User => User
- File => (no bundle)

--

### Entidades: Properties & Fields

**Properties**
- Comunes al Entity Type
- Ej: ID, Title, Author...

**Fields**
- Configurable por bundles
    - Base vs Instance
- Tipo de campo / Control / Formato

Se puede extender cada uno de ellos.

<!-- Propiedades => columna tabla
Fields => tabla a parte -->

--

### Entidades

![Entity](./img/entity.png)
> Fuente: [drupalize.me](https://drupalize.me/)

--

### Theming

IMAGEN ESTRUCTURA TEMA

--

### Theming: Rendarable arrays

--

### Display Suite + Context

- DS: Control de campos
- Context: Control granular de bloques
    - Block system on steroids

--

### Migrate

--

### Modulos interesantes

Entity
Global redirect
Context
Path breadcrumbs
Honeypot
Draggableviews
dragndrop_upload
transliteration
