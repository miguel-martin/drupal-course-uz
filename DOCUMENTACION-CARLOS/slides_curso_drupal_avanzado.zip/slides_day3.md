title: Curso Drupal avanzado
author:
  name: Carlos Sánchez
  twitter: _carletex_
  url: http://carletex.com
style: styles.css
output: index_day3.html

--

# Curso Drupal 7 avanzado
## Universidad de Zaragoza

    Dia 3. 20 Junio de 2016
    Carlos Sánchez

--

# Repaso

--

### Drupal 7. Modo de trabajo

- Perfiles de instalación
- Features
- Updates: hook_update_7XXX
- Control de versiones

--

### Menu router

Para crear nuevas rutas:
```php
/**
 * Implements hook_menu()
 */
function mimodulo_menu() { ... }
```
Podemos alterar rutas existentes:
```php
/**
 * Implements hook_menu_alter()
 */
function mimodulo_menu_alter() { ... }
```
--

### Menu router

Cada item de hook_menu:
```php
$items['miruta/%'] = array(
      'page callback' => 'mymodule_miruta_view',
      ...,
);
```

Componentes principales:

- title
- page_callback / page_arguments
- access_callback / access_arguments

--

### Form API

[API](https://api.drupal.org/api/drupal/developer!topics!forms_api_reference.html/7.x) de formularios Drupal
1. Formulario (mimodulo_form)
  - Crear componentes
2. Validar (mimodulo_form_validate)
  - form_set_error('campo', 'mensaje')
3. Envíar (mimodulo_form_submit)
  - Guardar datos

--

### Entidades

![Entity](./img/entity.png)
> Fuente: [drupalize.me](https://drupalize.me/)

--

### Custom entities

- Definir hook_entity_info
    - También entity_property_info_alter (integración views, pejemplo)
- Definir hook_schema (si necesitamos tablas)
    - [Schema reference](https://www.drupal.org/node/146939)
- Usar Entity API module
    - Extender controladores
    - Admin UI

--

### Ejercicios

1. Implementar ruta __/catalogo__ del ejercicio del catálogo

2. Implementar la entidad __calles__ (id - codpostal - calle).
  - Implementar una vista (filtrable por código postal) que saque es listado de Código postales,
localidad y calles

--

# Code!

--
### Migrate

- Framework de migración a Drupal
    - Sources: CSV, JSON, SQL...
    - Destination: Nodes, Users, Files...
- Competencia: feeds
    - users vs developers

> "The primary purpose is to provide the infrastructure for managing complex, large-scale site migrations"

--

### Migrate

__1. MigrateSource__

```php
 $this->source = new MigrateSourceCSV('/path/to/myfile.csv', $columns);
```


__2. MigrateDestination__

Role, User, Term, Node, Comment, EntityAPI, File, Table, Menus

```php
$this->destination = new MigrateDestinationNode('page');
```
--

### Migrate

__3. MigrateMap__

```php
$this->map = new MigrateSQLMap(
  $this->machineName,
  array(
    'codigoUnico' => array(
      'type' => 'int',
      'description' => 'id unico ',
    )
  ),
  MigrateDestinationNode::getKeySchema('page')
);
```

__4. MigrateFieldMapping__

```php
$this->addFieldMapping('title', 'source_subject');
```
--

### Migrate

![Migrate](./img/migrate.png)
> Fuente: [Migrate docs](https://www.drupal.org/node/1528934)

--

### Migrate

Métodos más usados Migrate:

```php
function prepareRow($row) {}
function complete($entity, stdClass $row) {}
function pre/postImport() {}
function pre/postRollback() {}
```

Otras consideraciones

- Track changes (en source)
- SourceMigration in field mappings
- Comandos drush

--

# Code!
