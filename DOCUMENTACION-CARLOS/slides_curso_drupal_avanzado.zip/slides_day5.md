title: Curso Drupal avanzado
author:
  name: Carlos Sánchez
  twitter: _carletex_
  url: http://carletex.com
style: styles.css
output: index_day5.html

--

# Curso Drupal 7 avanzado
## Universidad de Zaragoza

    Dia 5. 29 Junio de 2016
    Carlos Sánchez

--

### Theming

__Objetivo__: Cambiar la apariencia de nuestro sitio Drupal
- Themes
  - Estructura theme
  - template.php
  - theme_settings.php
- ¿Cómo usan los módulos el sistema de theming?
  - Theme functions
  - TPL's
  - Render arrays

--

# Themes

--

### Theming. Themes

![Theme flow](./img/theme_flow.png)
> Fuente: [Drupal 7 module development](https://www.drupal.org/node/1849934)

--
### Theming. Themes

__Opciones:__
1. Buscar un tema [contrib de Drupal](https://www.drupal.org/project/project_theme) y configurarlo desde UI
2. Extender un tema existente
  - Sub-theme
  - [Starter themes](https://www.drupal.org/node/323993) (Zen, Boostrap..)
3. Crear un tema custom

--

### Theming. Estructura themes

![Theme](./img/theme.png)
> Fuente: [Theming guide](https://www.drupal.org/node/171194)

--

### Theming. Estructura themes

[mitema.info](https://www.drupal.org/node/171205)

```php
name = Mi tema
....

# Regiones
regions[header] = Header
....
regions[footer] = Footer

# Styles & Scripts
stylesheets[all][] = css/styles.css
scripts[] = js/scripts.js

# Settings
settings[toggle_logo] = 1
```
--

### Theming. Estructura themes
__templates.tpl.php__
  - Plantillas HTML + PHP vars

__template.php__
  - Lógica y procesamiento (creación de vars, sobreescribir theme functions..)

__theme-settings.php__
  - Settings desde el UI (Form API)

--

# Module theming

--
### Theming. Modules

```php
// hook_block_view en mimodulo.info
$list = array('Perros','Gatos','Ratones');
$html = '<div class="list-items">';
foreach ($list as $element) {
  $html .= '<li>' . $element . '</li>';
}
$html .= '</div>';
return $html;
```

__VS.__

```php
$list = array('Perros','Gatos','Ratones');
$variables = array('items' => $list, 'type' => 'ul');
return theme('item_list', $variables);
```

--

### Theming. Theme functions

__theme_HOOKNAME($vars)__
- Se declaran en hook_theme

__Implementación__
```php
function theme_item_list($variables) {
  $items = $variables['items'];
  $title = $variables['title'];
  $type = $variables['type'];
  $attributes = $variables['attributes'];
  ....
}
```

__Llamada__
```php
$list = array('Perros','Gatos','Ratones');
$variables = array('items' => $list, 'type' => 'ul');
return theme('item_list', $variables);
```

--

### Theming. TPL's
__hook-name.tpl.php__
- Se declara en hook theme

__Implementación__
```html
// hook-name.tpl.php (ojo guiones! "_" => "-")
<div id="catalogo-<?php print $catalogo->id; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>

  <?php print render($title_prefix); ?>
  <?php if (!$page): ?>
    <h2<?php print $title_attributes; ?>>
      <a href="<?php print $catalogo_url; ?>"><?php print $title; ?></a>
    </h2>
  <?php endif; ?>
  <?php print render($title_suffix); ?>

</div>
```
__Llamada__
```php
$list = array('Perros','Gatos','Ratones');
$variables = array('items' => $list, 'type' => 'ul');
return theme('hook_name', $variables);
```
--

### Theming. hook_theme

En _hook_theme_ definimos como y con qué variables se van a renderizar nuestros datos
```php
// Implements hook_theme
function mimodulo_theme(){
  return array(
    'catalogo_page' => array(
        'template' => 'mydatafile',
        'variables' => array(
            'var1' => null,
            'var2' => null,
        ),
    ),
    'catalogo_bloque' => array(
      'variables' => array(
          'var1' => null,
          'var2' => null,
      ),
    )
  );
}
```
--


### Theming. (Pre)Process functions
__Preprocess functions__
  - Añadir variables nuevas
  - Moficar variables pasadas en la llamada a theme


__Process functions__
  - Acceso a todas las variables preprocesadas
  - Serializado para pintar en tpl

--

### Theming. (Pre)Process functions

1.   template_preprocess()
2.   template_preprocesss_HOOK()
3.   MODULE_preprocess()
4.   MODULE_preprocess_HOOK()
5.   THEME_preprocess()
6.   THEME_preprocess_HOOK()
7.   template_process()
8.   template_processs_HOOK()
9.   MODULE_process()
10.  MODULE_process_HOOK()
11.  THEME_process()
12.  THEME_process_HOOK()

--

### Theming. Render arrays
[Estructuras de datos](https://www.drupal.org/node/930760) para pasar como un único parametro __theme()__
- Data para renderizar
- CSS/JS para incluir en la página
- theme hooks a llamar
- Callback functions antes/despues del renderizado
- "Children" (arrays anidados)

```php
<?php print render($element); ?>
```

--
### Theming. Render arrays

```php
$element = array(
  '#prefix' => '<div class="less-simple">',
  '#suffix' => '</div>',
  'gato' => array(
    '#type' => 'link',
    '#title' => t('lol'),
    '#href' => 'admin/core/hack',
  ),
  'separador' => array(
    '#markup' => '<br />',
  ),
  'cuenta' => array(
  '#theme' => 'username',
  '#account' => $account,
),
```
--

# Code!

