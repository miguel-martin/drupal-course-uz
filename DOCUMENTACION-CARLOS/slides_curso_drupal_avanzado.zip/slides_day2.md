title: Curso Drupal avanzado
author:
  name: Carlos Sánchez
  twitter: _carletex_
  url: http://carletex.com
style: styles.css
output: index_day2.html

--

# Curso Drupal 7 avanzado
## Universidad de Zaragoza

    15/16 Junio de 2016
    Carlos Sánchez

--

# Repaso

--

### Drupal 7. Modo de trabajo

- Perfiles de instalación
- Features
- Updates: hook_update_7XXX
- Control de versiones

--

### Drupal7. Perfiles de instalación

- Contenedor
    - Modules (contrib, custom, features)
    - Themes
    - Libraries
- Paquete completo (CVS!)

```sh
## Reinstalar sitio
rm ../../sites/default/settings.php &&
mysql -u root -p -e 'drop database curso; create database curso;'
```

--

### Drupal7. Features

- Configuración BD <=> archivos
- 3 estados principales
	- **Default** (C = UG = BD)
	- **Overridden** (C != UG = BD || C = LG != BD)
	- **Needs review** (C != UG != BD)


- Revert VS. Recreate
- ¿Qué exportar?
- Añadidos: Strongarm + Features extra + role export...

<!-- Que exportar: ejemplo bloques. IDS, no bueno -->

--

### Drupal7. Updates

Cambios en BD, no exportados en features
ej:
- Añadir términos a una taxonomía
- Colocar un bloque nuevo
- Desactivar un módulo

```php
/**
 * Insert terms on the 'product' taxonomy
 */
mimodulo_update_7002() {
	...
}
```

--

### Drupal7. Control de versiones

- Control de versiones ^^
- Repositorio contiene perfil de instalación
- Deploys automáticos
    - Ej. git hooks + drush

```sh
drush updatedb -y && drush fra -y && drush cc all
```
--

### Examen sorpresa

- Quiero sincronizar la configuración del formato de texto Full HTML en todos mis entornos
	- ¿Cómo lo hago, siempre de la misma manera, o depende?


- Quiero borrar un vocabulario de taxonomía en todos los entornos
	- ¿Cómo lo hago?
	- ¿Qué tengo que tener en cuenta?

--

### Ejercicio práctico

Nuestro cliente tiene un e-commerce de venta de calzado, construido con Drupal.

Tiene un único catálogo en PDF con todos sus productos
y quiere mostrarlo un bloque de descarga en la barra lateral de la página.

--

### Ejercicio práctico

Requisitos:

- Quiere poder poner un texto justo debajo del enlace de descarga.
- Quiere poder marcar como "oferta total" para que se muestre un aviso de que todo el catálogo está al 20%.
- Quiere una página (/catalogo) con información más detallada del y el enlace de descarga.
- El cliente tiene que poder administrar el catálogo de manera fácil (poder subir subir un nuevo catálogo, poner texto, etc).
- Lo quiere para mañana y barato.

--

# ¿Soluciones?

--

### Menu router (no menu.module)

- Si me llega 'node/12' ¿Dónde voy?
	- Buscamos en la tabla menu_router
	- Llamamos a la función que nos indique

Ej: 'node/12/edit'

- node/12/edit
- node/12/%
- node/%/edit
- node/%/%
- node/12
- node/%
- node

--

### Menu router

Para crear nuevas rutas:
```php
/**
 * Implements hook_menu()
 */
function mimodulo_menu() { ... }
```
Podemos alterar rutas existentes:
```php
/**
 * Implements hook_menu_alter()
 */
function mimodulo_menu_alter() { ... }
```
--

### Menu router

Cada item de hook_menu:
```php
$items['miruta/%'] = array(
      'page callback' => 'mymodule_miruta_view',
      ...,
);
```

Componentes principales:

- title
- page_callback / page_arguments
- access_callback / access_arguments

--

# Code!

--

### Form API

[API](https://api.drupal.org/api/drupal/developer!topics!forms_api_reference.html/7.x) de formularios Drupal
1. Formulario (mimodulo_form)
  - Crear componentes
2. Validar (mimodulo_form_validate)
  - form_set_error('campo', 'mensaje')
3. Envíar (mimodulo_form_submit)
  - Guardar datos

--

### Ejercicio práctico II

El mismo cliente quiere guardar todos los códigos postales existentes para saber la localidad/zona a la que se envían los pedidos y en un futuro poder hacer integraciones.

--

# ¿Soluciones?

--

### Entidades

- Abstracción de funcionalidad para diferentes componentes
    (Nodes, Users...)

**Entities**:
- Entity Types
- Bundles
- Properties && Fields
- Entidad

<!-- fields para todas entitades, entity->save() -->

--

### Entidades: Entity Types

En Drupal 7:

- Nodes
- Comments
- Users
- Taxonomy (terms & vocabularies)
- Files
- No blocks :( => Bean!
- Other entities
    - **Custom**: Recomendado usar Entity API
    - **Contrib**: Drupal commerce

--

### Entidades: Bundles

Cuando queremos que nuestras entidades sean «fieldables».

- Node => Página básica, Artículo, ...
- User => User
- File => (no bundle)

--

### Entidades: Properties & Fields

**Properties**
- Comunes al Entity Type
- Ej: ID, Title, Author...

**Fields**
- Configurable por bundles
    - Base vs Instance
- Tipo de campo / Control / Formato

Se puede extender cada uno de ellos.

<!-- Propiedades => columna tabla
Fields => tabla a parte -->

--

### Entidades

![Entity](./img/entity.png)
> Fuente: [drupalize.me](https://drupalize.me/)

--

### Custom entities

- Definir hook_entity_info
    - También entity_property_info_alter (integración views, pejemplo)
- Definir hook_schema (si necesitamos tablas)
    - [Schema reference](https://www.drupal.org/node/146939)
- Usar Entity API module
    - Extender controladores
    - Admin UI

--

# Code!

--

### Configuration management

- En Drupal 8 se puede exportar desde el core
- En Drupal 7, se ha copiado el [proyecto](https://www.drupal.org/project/configuration)

Las features aún tienen sentido! => Exportar funcionalidad para otro proyectos

--

### Extras

- Devel menu items