title: Curso Drupal avanzado
author:
  name: Carlos Sánchez
  twitter: _carletex_
  url: http://carletex.com
style: styles.css
output: index_day4.html

--

# Curso Drupal 7 avanzado
## Universidad de Zaragoza

    Dia 4. 27 Junio de 2016
    Carlos Sánchez

--

### Migrate

- Framework de migración a Drupal
    - Sources: CSV, JSON, SQL...
    - Destination: Nodes, Users, Files...
- Competencia: feeds
    - users vs developers

> "The primary purpose is to provide the infrastructure for managing complex, large-scale site migrations"

--

### Migrate

__1. MigrateSource__

```php
 $this->source = new MigrateSourceCSV('/path/to/myfile.csv', $columns);
```


__2. MigrateDestination__

Role, User, Term, Node, Comment, EntityAPI, File, Table, Menus

```php
$this->destination = new MigrateDestinationNode('page');
```
--

### Migrate

__3. MigrateMap__

```php
$this->map = new MigrateSQLMap(
  $this->machineName,
  array(
    'codigoUnico' => array(
      'type' => 'int',
      'description' => 'id unico ',
    )
  ),
  MigrateDestinationNode::getKeySchema('page')
);
```

__4. MigrateFieldMapping__

```php
$this->addFieldMapping('title', 'source_subject');
```
--

### Migrate

![Migrate](./img/migrate.png)
> Fuente: [Migrate docs](https://www.drupal.org/node/1528934)

--

### Migrate

Métodos más usados Migrate:

```php
function prepareRow($row) {}
function complete($entity, stdClass $row) {}
function pre/postImport() {}
function pre/postRollback() {}
```

Otras consideraciones

- Track changes (en source)
- SourceMigration in field mappings
- Comandos drush

--

# Code!
